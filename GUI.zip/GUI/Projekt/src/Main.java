import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;

public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        stage.setTitle("GPS");

        stage.setWidth(700);
        stage.setHeight(500);
        stage.setX(300);
        stage.setY(100);
        VBox root = new VBox();
        Button nupp1 = new Button("New route");
        Button nupp2 = new Button("Load Map");
        //Button nupp2 = new Button("Load map file");
        //ImageView imageView = new ImageView("http://www.thepluspaper.com/wp-content/uploads/2019/01/1.jpg");

        //nupp1.setOnAction(e -> {
            //System.out.println("Esimene Töötab");
        //});
        //nupp2.setOnAction(e -> {
            //System.out.println("Teine Töötab");
        //});
        root.getChildren().add(nupp1);
        root.getChildren().add(nupp2);
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }
    public static void main(String[] args) { launch(args);}
}
